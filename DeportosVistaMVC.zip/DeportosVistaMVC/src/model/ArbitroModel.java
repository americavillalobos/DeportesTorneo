/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:08/06/2023
*Descripción: clase model arbitro
 */
package model;

import entity.Arbitro;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ArbitroModel implements IArbitroModel {
    /**
     * El método crea un árbitro
     * @param lista es una lista para almacenar los árbitros.
     * @param arbitro es un objeto específico de árbitro.
     */
    @Override
    public void crearRegistro(List<Arbitro> lista, Arbitro arbitro) {
        lista.add(arbitro);
    }

    /**
     * El método elimina un árbitro
     * @param lista
     * @param nombre 
     */
    @Override
    public void eliminarRegistro(List<Arbitro> lista, String nombre) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getNombre().compareTo(nombre) == 0) {
                lista.remove(i);

                break;
            }
        }

    }

   
    /**
     * El método actualiza un árbitro
     * @param lista
     * @param arbitro 
     */
    @Override
    public void actualizarRegistro(List<Arbitro> lista, Arbitro arbitro) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getNombre().compareTo(arbitro.getNombre()) == 0) {
                lista.set(i, arbitro);
                break;
            }
        }
    }

    /**
     *El método muestra un árbitro
     * @param lista
     * @param modelo 
     */
    @Override
    public void mostrarRegistro(List<Arbitro> lista, DefaultTableModel modelo) {
        modelo.setRowCount(0);
        for (int i = 0; i < lista.size(); i++) {
            Object[] fila = new Object[3];

            fila[0] = lista.get(i).getNombre();
            fila[1] = lista.get(i).getExperiencia();
            fila[2] = lista.get(i).getNivel();

            modelo.addRow(fila);
        }
    }
}
