/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:20/05/2023
*Fecha de actualización:21/05/2023
*Descripción:Esta es la clase entrenador tiene como clase padre a la clase persona
 */
package entity;

/**
 * Se declararon los atributos de la clase entrenador con sus getter and setter
 *
 */
public class Entrenador extends Persona {

    private String equipo;

    public Entrenador() {
    }

    public Entrenador(String equipo) {

        this.equipo = equipo;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

}
