/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:22/05/2023
*Fecha de actualización:10/06/2023
*Descripción:Estaes la clase vista torneo donde se registra el torneo y 
*su categoria genera el torneo
 */
package view;

import controller.EquipoController;
import entity.Torneo;
import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VistaTorneo extends javax.swing.JFrame {

   
    private final DefaultTableModel modeloTable;
    private Torneo torneo;

    private final EquipoController equipoController;
    private final MenuVista menuVista;

    public VistaTorneo(MenuVista menuVista) {
        initComponents();
        this.equipoController = new EquipoController();
        this.menuVista = menuVista;
        this.modeloTable = (DefaultTableModel) TablaTorneo.getModel();

        this.equipoController.mostrarRegistro(this.menuVista.listaEquipo, 
                modeloTable);

        ImageIcon imagen = new ImageIcon("./src/images/cancha.jpg");
        Icon icono = new ImageIcon(imagen.getImage().getScaledInstance(
                wallpaper.getWidth(),
                wallpaper.getHeight(), Image.SCALE_DEFAULT));
        wallpaper.setIcon(icono);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Titulo = new javax.swing.JLabel();
        Titulo2 = new javax.swing.JLabel();
        NombreTorneo = new javax.swing.JTextField();
        Categoria1 = new javax.swing.JLabel();
        Categoria2 = new javax.swing.JComboBox<>();
        GenerarTorneo = new javax.swing.JButton();
        BotonRegistrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaTorneo = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        MostrarTorneo = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        Pizarron = new javax.swing.JTextArea();
        BotonRegresar = new javax.swing.JButton();
        wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Titulo.setFont(new java.awt.Font("Waree", 1, 36)); // NOI18N
        Titulo.setForeground(new java.awt.Color(255, 255, 255));
        Titulo.setText("Torneo");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, 150, 50));

        Titulo2.setFont(new java.awt.Font("Waree", 1, 18)); // NOI18N
        Titulo2.setForeground(new java.awt.Color(255, 255, 255));
        Titulo2.setText("Ingrese el nombre del torneo");
        jPanel1.add(Titulo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 300, 30));
        jPanel1.add(NombreTorneo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 170, 30));

        Categoria1.setFont(new java.awt.Font("Waree", 1, 18)); // NOI18N
        Categoria1.setForeground(new java.awt.Color(255, 255, 255));
        Categoria1.setText("Categoria ");
        jPanel1.add(Categoria1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 90, -1, -1));

        Categoria2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A", "B", "C", "D", "E" }));
        jPanel1.add(Categoria2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 130, -1, 30));

        GenerarTorneo.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        GenerarTorneo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/eliminatoria.png"))); // NOI18N
        GenerarTorneo.setText("Generar Torneo");
        GenerarTorneo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GenerarTorneoMouseClicked(evt);
            }
        });
        jPanel1.add(GenerarTorneo, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 504, -1, 70));

        BotonRegistrar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonRegistrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/nota.png"))); // NOI18N
        BotonRegistrar.setText("Registra");
        BotonRegistrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonRegistrarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 180, 140, 40));

        TablaTorneo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Equipo", "Estadio"
            }
        ));
        jScrollPane1.setViewportView(TablaTorneo);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 420, 250));

        MostrarTorneo.setEditable(false);
        MostrarTorneo.setColumns(20);
        MostrarTorneo.setRows(5);
        jScrollPane3.setViewportView(MostrarTorneo);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 110, 300, 50));

        Pizarron.setEditable(false);
        Pizarron.setBackground(new java.awt.Color(0, 0, 0));
        Pizarron.setColumns(20);
        Pizarron.setFont(new java.awt.Font("Waree", 1, 12)); // NOI18N
        Pizarron.setForeground(new java.awt.Color(255, 255, 255));
        Pizarron.setRows(5);
        jScrollPane2.setViewportView(Pizarron);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 240, 310, 240));

        BotonRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/regresar.png"))); // NOI18N
        BotonRegresar.setBorder(null);
        BotonRegresar.setBorderPainted(false);
        BotonRegresar.setContentAreaFilled(false);
        BotonRegresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonRegresarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 500, -1, -1));

        wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cancha.jpg"))); // NOI18N
        jPanel1.add(wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 590));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 610));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    /**
     *
     * Este boton es para guardar los datos ingresados por el usuario despues de
     * ser registrados los muestra en un mostrar torneo
     */
    private void BotonRegistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegistrarMouseClicked

        String nombreTorneo = NombreTorneo.getText();
        String categoria = Categoria2.getSelectedItem().toString(); 

        if (nombreTorneo.isEmpty()) {
          
            JOptionPane.showMessageDialog(this, 
                    "Por favor, ingresa el nombre del torneo.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            
        } else {
            
            torneo = new Torneo(nombreTorneo, categoria);

            // Mostrar los valores registrados en una etiqueta
            String nombreTorneoRegistrado = torneo.getNombreTorneo();
            String categoriaRegistrada = torneo.getCategoria();

            MostrarTorneo.setText("Nombre del torneo: " + 
              nombreTorneoRegistrado + ", Categoría: " + categoriaRegistrada);
            
        }
        
    }//GEN-LAST:event_BotonRegistrarMouseClicked

    /**
     * botón y el código asociado generan los enfrentamientos para un torneo 
     * con una lista de equipos y los muestra en un componente de interfaz 
     * de usuario. 
     * 
     */
    private void GenerarTorneoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GenerarTorneoMouseClicked

         List<String> equipos = new ArrayList<>();

    for (int i = 0; i < modeloTable.getRowCount(); i++) {
        String equipo = modeloTable.getValueAt(i, 0).toString();
        equipos.add(equipo);
    }

    List<String> enfrentamientos = new ArrayList<>();
        
    if (equipos.size() % 2 != 0) {
        equipos.add("Descanso");
    }
  
    int numRondas = equipos.size();
    int numEquipos = equipos.size();

    for (int ronda = 0; ronda < numRondas - 1; ronda++) {
        int equipoFijoIndex = ronda % numEquipos;
        String equipoFijo = equipos.get(equipoFijoIndex);

        for (int i = 0; i < numEquipos / 2; i++) {
            int equipo1Index = (ronda + i + 1) % numEquipos;
            int equipo2Index = (numEquipos - 1 - i + ronda) % numEquipos;

            String equipo1 = equipos.get(equipo1Index);
            String equipo2 = equipos.get(equipo2Index);

            if (!equipo1.equals(equipo2)) {
                String enfrentamiento = equipo1 + " vs " + equipo2;
                enfrentamientos.add(enfrentamiento);
            }
        }

        String enfrentamientoFijo = equipoFijo + " vs Descanso";
        enfrentamientos.add(enfrentamientoFijo);
    }

    for (String enfrentamiento : enfrentamientos) {
        Pizarron.append(enfrentamiento + "\n");
        
    }
        
    }//GEN-LAST:event_GenerarTorneoMouseClicked

    /**
     * al hacer clic en este botón, se oculta la ventana actual y se muestra la 
     * vista del menú, lo que permite al usuario regresar a la pantalla 
     * o menú anterior.
     *  
     */
    private void BotonRegresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegresarMouseClicked
       
        this.setVisible(false);
        this.menuVista.setVisible(true);
    }//GEN-LAST:event_BotonRegresarMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonRegistrar;
    private javax.swing.JButton BotonRegresar;
    private javax.swing.JLabel Categoria1;
    private javax.swing.JComboBox<String> Categoria2;
    private javax.swing.JButton GenerarTorneo;
    private javax.swing.JTextArea MostrarTorneo;
    private javax.swing.JTextField NombreTorneo;
    private javax.swing.JTextArea Pizarron;
    private javax.swing.JTable TablaTorneo;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel Titulo2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel wallpaper;
    // End of variables declaration//GEN-END:variables
}
