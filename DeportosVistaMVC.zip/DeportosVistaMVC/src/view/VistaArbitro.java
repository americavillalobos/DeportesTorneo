/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:20/05/2023
*Fecha de actualización:22/05/2023
*Descripción:ventana vista Arbitro
 */
package view;

import controller.ArbitroController;
import entity.Arbitro;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VistaArbitro extends javax.swing.JFrame {

    private final ArbitroController arbitroController;
    private final MenuVista menuVista;
    

    private final DefaultTableModel modelo;
    
   /**
    * Estas líneas de código se utilizan para cargar una imagen de un archivo 
    * y establecerla como el ícono de un componente llamado wallpaper.
    * @param menuVista 
    */
    public VistaArbitro(MenuVista menuVista) {
        initComponents();
 
       ImageIcon imagen = new ImageIcon("./src/images/cancha.jpg");
       Icon icono = new ImageIcon(imagen.getImage().
               getScaledInstance(wallpaper.getWidth(),
               wallpaper.getHeight(), Image.SCALE_DEFAULT));
       wallpaper.setIcon(icono);

       arbitroController = new ArbitroController();
        this.menuVista = menuVista;

        modelo = (DefaultTableModel) TableArbitro.getModel();
        
        setResizable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        Experiencia = new javax.swing.JLabel();
        experiencia = new javax.swing.JComboBox<>();
        Nivel = new javax.swing.JLabel();
        nivel = new javax.swing.JComboBox<>();
        BotonRegistrar = new javax.swing.JButton();
        BotonEditar = new javax.swing.JButton();
        BotonEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableArbitro = new javax.swing.JTable();
        BotonRegresar = new javax.swing.JButton();
        imagen = new javax.swing.JLabel();
        contenedor = new javax.swing.JLabel();
        wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Waree", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Árbitro");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 150, 60));

        Nombre.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        Nombre.setForeground(new java.awt.Color(255, 255, 255));
        Nombre.setText("Nombre");
        jPanel1.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, -1, -1));

        nombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nombreKeyTyped(evt);
            }
        });
        jPanel1.add(nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 90, 100, -1));

        Experiencia.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        Experiencia.setForeground(new java.awt.Color(255, 255, 255));
        Experiencia.setText("Experiencia");
        jPanel1.add(Experiencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, -1, -1));

        experiencia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1 año", "2 años", "3 años", "4 años", "5 años ", "6 años" }));
        jPanel1.add(experiencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 90, -1, -1));

        Nivel.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        Nivel.setForeground(new java.awt.Color(255, 255, 255));
        Nivel.setText("Nivel");
        jPanel1.add(Nivel, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, -1, -1));

        nivel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Principiante", "Intermedio", "Experto" }));
        jPanel1.add(nivel, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 140, -1, -1));

        BotonRegistrar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonRegistrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/nota.png"))); // NOI18N
        BotonRegistrar.setText("Registrar");
        BotonRegistrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonRegistrarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 200, -1, -1));

        BotonEditar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/editarcodigo.png"))); // NOI18N
        BotonEditar.setText("Editar");
        BotonEditar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEditarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 270, 140, -1));

        BotonEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/basura.png"))); // NOI18N
        BotonEliminar.setText("Eliminar");
        BotonEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEliminarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 340, 140, -1));

        TableArbitro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Experiencia", "Nivel"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableArbitro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableArbitroMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TableArbitro);
        if (TableArbitro.getColumnModel().getColumnCount() > 0) {
            TableArbitro.getColumnModel().getColumn(0).setResizable(false);
            TableArbitro.getColumnModel().getColumn(1).setResizable(false);
            TableArbitro.getColumnModel().getColumn(2).setResizable(false);
        }

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 510, 320));

        BotonRegresar.setBackground(new java.awt.Color(242, 242, 242));
        BotonRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/regresar.png"))); // NOI18N
        BotonRegresar.setContentAreaFilled(false);
        BotonRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(BotonRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 440, -1, -1));

        imagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/arbitro (1).png"))); // NOI18N
        jPanel1.add(imagen, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 10, 170, 130));

        contenedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/balon.jpg"))); // NOI18N
        jPanel1.add(contenedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, -10, 210, 550));

        wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cancha.jpg"))); // NOI18N
        jPanel1.add(wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 540));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 780, 550));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * cuando se hace clic en el botón "BotonRegistrar", este código verifica 
     * si se han completado los campos requeridos. Si los campos están vacíos, 
     * muestra un mensaje de advertencia. Si los campos tienen valores, crea 
     * un objeto Arbitro, lo guarda en una lista y muestra los registros en 
     * una tabla.
     */
    private void BotonRegistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegistrarMouseClicked

     if (nombre.getText().isEmpty() || experiencia.getSelectedItem() == null 
             || nivel.getSelectedItem() == null) {
         
     JOptionPane.showMessageDialog(null, 
             "Tienes que rellenar los campos.");
     
     } else {
         
   Arbitro arbitro = new Arbitro();
   arbitro.setNombre(this.nombre.getText());
   arbitro.setExperiencia(this.experiencia.getSelectedItem().toString());
   arbitro.setNivel(this.nivel.getSelectedItem().toString());

    arbitroController.crearRegistro(this.menuVista.listaArbitro, arbitro);
    arbitroController.mostrarRegistro(this.menuVista.listaArbitro, modelo);

        }
    }//GEN-LAST:event_BotonRegistrarMouseClicked

    /**
     * El botón en este código busca un árbitro en una lista, lo actualiza con 
     * los nuevos valores ingresados en la interfaz gráfica y luego guarda y 
     * muestra los cambios realizados.
     *
     */
    private void BotonEditarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEditarMouseClicked

    Arbitro arbitro = new Arbitro();
    arbitro.setNombre(this.nombre.getText());
    arbitro.setExperiencia(this.experiencia.getSelectedItem().toString());
    arbitro.setNivel(this.nivel.getSelectedItem().toString());

    for (int i = 0; i < this.menuVista.listaArbitro.size(); i++) {
        
     if (this.menuVista.listaArbitro.get(i).getNombre().
             compareTo(arbitro.getNombre()) == 0) {
         
    this.menuVista.listaArbitro.set(i, arbitro);

    arbitroController.actualizarRegistro(this.menuVista.listaArbitro, arbitro);
    arbitroController.mostrarRegistro(this.menuVista.listaArbitro, modelo);

            }
        }
    }//GEN-LAST:event_BotonEditarMouseClicked

    /**
     *este botón permite eliminar el árbitro seleccionado de la lista y 
     * actualiza la interfaz gráfica para reflejar los cambios. 
     * Antes de eliminar, muestra un cuadro de diálogo de confirmación para 
     * que el usuario confirme su acción.
     * 
     */
    private void BotonEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEliminarMouseClicked
        
    String nombre = TableArbitro.getValueAt(TableArbitro.getSelectedRow()
            , 0).toString();
    int opcion = JOptionPane.showConfirmDialog(null,
            "¿Estás seguro de eliminar?", "Confirmación",
            JOptionPane.OK_CANCEL_OPTION);
    
    if (opcion == JOptionPane.OK_OPTION) {
        
    arbitroController.eliminarRegistro(this.menuVista.listaArbitro, nombre);
    arbitroController.mostrarRegistro(this.menuVista.listaArbitro, modelo);

        }
    }//GEN-LAST:event_BotonEliminarMouseClicked

    /**
     * permite que los datos del árbitro seleccionado se muestren en 
     * los campos correspondientes para su visualización o edición.
     *
     */
    private void TableArbitroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableArbitroMouseClicked

    this.nombre.setText(TableArbitro.getValueAt(TableArbitro
            .getSelectedRow(),0).toString());
    
    this.experiencia.setSelectedItem(TableArbitro.getValueAt
        (TableArbitro.getSelectedRow(), 1).toString());
    
     this.nivel.setSelectedItem(TableArbitro.getValueAt
        (TableArbitro.getSelectedRow(), 2).toString());
     
    }//GEN-LAST:event_TableArbitroMouseClicked

    /**
     * cuando se hace clic en el botón, este código imprime un mensaje en 
     * la consola, oculta la ventana actual
     * y muestra otra ventana llamada menuVista.
     * 
     */
    private void BotonRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonRegresarActionPerformed
       
        this.setVisible(false);
        this.menuVista.setVisible(true);

    }//GEN-LAST:event_BotonRegresarActionPerformed
    /**
     * 
     * este código permite que solo se ingresen letras
     * en el campo de texto asociado. 
     */
    private void nombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombreKeyTyped
      
        char letra = evt.getKeyChar();
    if (Character.isLetter(letra)) {
      
    } else {
        
        evt.consume();
    JOptionPane.showMessageDialog(null,
            "Solo se admiten letras");
    }
    
    }//GEN-LAST:event_nombreKeyTyped


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonEditar;
    private javax.swing.JButton BotonEliminar;
    private javax.swing.JButton BotonRegistrar;
    private javax.swing.JButton BotonRegresar;
    private javax.swing.JLabel Experiencia;
    private javax.swing.JLabel Nivel;
    private javax.swing.JLabel Nombre;
    private javax.swing.JTable TableArbitro;
    private javax.swing.JLabel contenedor;
    private javax.swing.JComboBox<String> experiencia;
    private javax.swing.JLabel imagen;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> nivel;
    private javax.swing.JTextField nombre;
    private javax.swing.JLabel wallpaper;
    // End of variables declaration//GEN-END:variables
}
