/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:20/05/2023
*Fecha de actualización:21/05/2023
*Descripción:.ventana vista
 */
package view;

import controller.JugadorController;
import entity.Jugador;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VistaJugador extends javax.swing.JFrame {

    private final JugadorController jugadorController;
    private final MenuVista menuVista;

    private final DefaultTableModel modelo;

    public VistaJugador(MenuVista menuVista) {
        initComponents();
        
        ImageIcon imagen = new ImageIcon("./src/images/cancha.jpg");
        Icon icono = new ImageIcon(imagen.getImage()
                .getScaledInstance(wallpaper.getWidth(),
                wallpaper.getHeight(), Image.SCALE_DEFAULT));
        wallpaper.setIcon(icono);

        jugadorController = new JugadorController();
        this.menuVista = menuVista;
        modelo = (DefaultTableModel) TableJugador.getModel();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Titulo = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        Posicion = new javax.swing.JLabel();
        Posicion2 = new javax.swing.JComboBox<>();
        Numplayera = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableJugador = new javax.swing.JTable();
        Registrar = new javax.swing.JButton();
        BotonEditar = new javax.swing.JButton();
        BotonEliminar = new javax.swing.JButton();
        Equipo1 = new javax.swing.JComboBox<>();
        Equipo = new javax.swing.JLabel();
        BotonRegresar = new javax.swing.JButton();
        imagen = new javax.swing.JLabel();
        Contenedor = new javax.swing.JLabel();
        Numero2 = new javax.swing.JComboBox<>();
        wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Titulo.setFont(new java.awt.Font("Waree", 1, 24)); // NOI18N
        Titulo.setForeground(new java.awt.Color(255, 255, 255));
        Titulo.setText("Jugador");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 10, 110, 40));

        Nombre.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        Nombre.setForeground(new java.awt.Color(255, 255, 255));
        Nombre.setText("Nombre");
        jPanel1.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        nombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nombreKeyTyped(evt);
            }
        });
        jPanel1.add(nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 80, 120, -1));

        Posicion.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        Posicion.setForeground(new java.awt.Color(255, 255, 255));
        Posicion.setText("Posición");
        jPanel1.add(Posicion, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 80, -1, -1));

        Posicion2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Portero", "Defensa", "Centrocampista", "Delantero" }));
        jPanel1.add(Posicion2, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 80, -1, -1));

        Numplayera.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        Numplayera.setForeground(new java.awt.Color(255, 255, 255));
        Numplayera.setText("Numero de playera");
        jPanel1.add(Numplayera, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, -1, -1));

        TableJugador.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Posición", "Numero de playera", "Equipo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableJugador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableJugadorMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TableJugador);
        if (TableJugador.getColumnModel().getColumnCount() > 0) {
            TableJugador.getColumnModel().getColumn(0).setResizable(false);
            TableJugador.getColumnModel().getColumn(1).setResizable(false);
            TableJugador.getColumnModel().getColumn(2).setResizable(false);
            TableJugador.getColumnModel().getColumn(3).setResizable(false);
        }

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 570, 340));

        Registrar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        Registrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/nota.png"))); // NOI18N
        Registrar.setText("Registrar");
        Registrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RegistrarMouseClicked(evt);
            }
        });
        jPanel1.add(Registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 210, 170, -1));

        BotonEditar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/editarcodigo.png"))); // NOI18N
        BotonEditar.setText("Editar");
        BotonEditar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEditarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 270, 170, -1));

        BotonEliminar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/basura.png"))); // NOI18N
        BotonEliminar.setText("Eliminar");
        BotonEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEliminarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 330, 170, -1));

        Equipo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "America", "Chivas ", "Cruz azul", "Tigres", "Toluca", "Pumas" }));
        jPanel1.add(Equipo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 120, -1, -1));

        Equipo.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        Equipo.setForeground(new java.awt.Color(255, 255, 255));
        Equipo.setText("Equipo");
        jPanel1.add(Equipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 120, -1, -1));

        BotonRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/regresar.png"))); // NOI18N
        BotonRegresar.setContentAreaFilled(false);
        BotonRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(BotonRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 420, -1, -1));

        imagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/director (1).png"))); // NOI18N
        jPanel1.add(imagen, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 60, 100, 120));

        Contenedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/balon.jpg"))); // NOI18N
        jPanel1.add(Contenedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 0, 230, 550));

        Numero2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10" }));
        jPanel1.add(Numero2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, -1, -1));

        wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cancha.jpg"))); // NOI18N
        jPanel1.add(wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 880, 550));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 880, 550));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     *
     * Este es el botón que registra a un jugador en la tabla
     */
    private void RegistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RegistrarMouseClicked

        if (nombre.getText().isEmpty() || Posicion2.getSelectedItem() == null || Numero2.getSelectedItem() == null || Equipo1.getSelectedItem() == null) {
        JOptionPane.showMessageDialog(null, "Tienes que rellenar los campos.");
    } else {
        Jugador jugador = new Jugador();
        jugador.setNombre(this.nombre.getText());
        jugador.setPosicion(this.Posicion2.getSelectedItem().toString());
        jugador.setNumeroCamiseta(this.Numero2.getSelectedItem().toString());
        jugador.setEquipo(this.Equipo1.getSelectedItem().toString());

        jugadorController.crearRegistro(this.menuVista.listaJugador, jugador);
        jugadorController.mostrarRegistro(this.menuVista.listaJugador, modelo);
    }

    }//GEN-LAST:event_RegistrarMouseClicked
    /**
     * Este botón es para editar
     *
     */
    private void BotonEditarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEditarMouseClicked
        Jugador jugador = new Jugador();
        jugador.setNombre(this.nombre.getText());
        jugador.setPosicion(this.Posicion2.getSelectedItem().toString());
        jugador.setNumeroCamiseta(this.Numero2.getSelectedItem().toString());
        jugador.setEquipo(this.Equipo1.getSelectedItem().toString());

        for (int i = 0; i < this.menuVista.listaJugador.size(); i++) {
            if (this.menuVista.listaJugador.get(i).getNombre().compareTo(jugador.getNombre()) == 0) {
                this.menuVista.listaJugador.set(i, jugador);

                jugadorController.actualizarRegistro(this.menuVista.listaJugador, jugador);
                jugadorController.mostrarRegistro(this.menuVista.listaJugador, modelo);

            }
        }


    }//GEN-LAST:event_BotonEditarMouseClicked
    /**
     *
     * Eliminar un entrenador
     */
    private void BotonEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEliminarMouseClicked

        String nombre = TableJugador.getValueAt(TableJugador.getSelectedRow(), 0).toString();
        int opcion = JOptionPane.showConfirmDialog(null, "¿Estás seguro de eliminar?", "Confirmación", JOptionPane.OK_CANCEL_OPTION);
        if (opcion == JOptionPane.OK_OPTION) {
            jugadorController.eliminarRegistro(this.menuVista.listaJugador, nombre);
            jugadorController.mostrarRegistro(this.menuVista.listaJugador, modelo);

        }

    }//GEN-LAST:event_BotonEliminarMouseClicked

   /**
     *
     * Este es para actualizar
     */
    private void TableJugadorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableJugadorMouseClicked

        this.nombre.setText(TableJugador.getValueAt(TableJugador.getSelectedRow(), 0).toString());
        this.Posicion2.setSelectedItem(TableJugador.getValueAt(TableJugador.getSelectedRow(), 1).toString());
        this.Numero2.setSelectedItem(TableJugador.getValueAt(TableJugador.getSelectedRow(), 2).toString());
        this.Equipo1.setSelectedItem(TableJugador.getValueAt(TableJugador.getSelectedRow(), 3).toString());

    }//GEN-LAST:event_TableJugadorMouseClicked

    private void BotonRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonRegresarActionPerformed
        this.setVisible(false);
        ///MenuVista menu = new MenuVista(this.menuVista.listaArbitro);
        this.menuVista.setVisible(true);

        // dispose(); Destruye el frame o la pantalla
    }//GEN-LAST:event_BotonRegresarActionPerformed

    private void nombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombreKeyTyped
        char letra = evt.getKeyChar();
        if (Character.isLetter(letra)) {
            // Permite la entrada de letras
        } else {
            // Bloquea la entrada de caracteres no permitidos
            evt.consume();
            JOptionPane.showMessageDialog(null, "Solo se admiten letras");
        }
    }//GEN-LAST:event_nombreKeyTyped


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonEditar;
    private javax.swing.JButton BotonEliminar;
    private javax.swing.JButton BotonRegresar;
    private javax.swing.JLabel Contenedor;
    private javax.swing.JLabel Equipo;
    private javax.swing.JComboBox<String> Equipo1;
    private javax.swing.JLabel Nombre;
    private javax.swing.JComboBox<String> Numero2;
    private javax.swing.JLabel Numplayera;
    private javax.swing.JLabel Posicion;
    private javax.swing.JComboBox<String> Posicion2;
    private javax.swing.JButton Registrar;
    private javax.swing.JTable TableJugador;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel imagen;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField nombre;
    private javax.swing.JLabel wallpaper;
    // End of variables declaration//GEN-END:variables

}
