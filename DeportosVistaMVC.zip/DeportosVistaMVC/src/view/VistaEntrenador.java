/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:20/05/2023
*Fecha de actualización:08/06/2023
*Descripción:.ventana vista
 */
package view;

import controller.EntrenadorController;
import entity.Entrenador;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VistaEntrenador extends javax.swing.JFrame {

    private final EntrenadorController entrenadorController;
    private final MenuVista menuVista;

    private final DefaultTableModel modelo;

    /**
    * Estas líneas de código se utilizan para cargar una imagen de un archivo 
    * y establecerla como el ícono de un componente llamado wallpaper.
    * @param menuVista 
    */
    public VistaEntrenador(MenuVista menuVista) {
        initComponents();

        ImageIcon imagen = new ImageIcon("./src/images/cancha.jpg");
        Icon icono = new ImageIcon(imagen.getImage().getScaledInstance
        (wallpaper.getWidth(),
                wallpaper.getHeight(), Image.SCALE_DEFAULT));
        wallpaper.setIcon(icono);

        entrenadorController = new EntrenadorController();
        this.menuVista = menuVista;

        modelo = (DefaultTableModel) TableEntrenador.getModel();
        
        setResizable(false);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Titulo = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        nombre = new javax.swing.JComboBox<>();
        Equipo = new javax.swing.JLabel();
        equipo = new javax.swing.JComboBox<>();
        BotonRegistrar = new javax.swing.JButton();
        BotonEditar = new javax.swing.JButton();
        BotonEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableEntrenador = new javax.swing.JTable();
        Regresar = new javax.swing.JButton();
        Imagen = new javax.swing.JLabel();
        Contenedor = new javax.swing.JLabel();
        wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Titulo.setBackground(new java.awt.Color(255, 255, 255));
        Titulo.setFont(new java.awt.Font("Waree", 1, 24)); // NOI18N
        Titulo.setForeground(new java.awt.Color(255, 255, 255));
        Titulo.setText("Entrenador");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 0, 150, 50));

        Nombre.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        Nombre.setForeground(new java.awt.Color(255, 255, 255));
        Nombre.setText("Nombre");
        jPanel1.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        nombre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fernando Ortiz", "Veljko Paunovic", "Ricardo Ferretti", "Robert Siboldi ", "Ignacio Ambriz", "Hugo Sánchez" }));
        jPanel1.add(nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, -1, -1));

        Equipo.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        Equipo.setForeground(new java.awt.Color(255, 255, 255));
        Equipo.setText("Equipo");
        jPanel1.add(Equipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 100, -1, -1));

        equipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "America", "Chivas ", "Cruz azul", "Tigres", "Toluca", "Pumas" }));
        jPanel1.add(equipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 100, -1, -1));

        BotonRegistrar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonRegistrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/nota.png"))); // NOI18N
        BotonRegistrar.setText("Registrar");
        BotonRegistrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonRegistrarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 220, -1, -1));

        BotonEditar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/editarcodigo.png"))); // NOI18N
        BotonEditar.setText("Editar");
        BotonEditar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEditarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 280, 140, -1));

        BotonEliminar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/basura.png"))); // NOI18N
        BotonEliminar.setText("Eliminar");
        BotonEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEliminarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 340, 140, -1));

        TableEntrenador.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Nombre", "Equipo"
            }
        ));
        TableEntrenador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableEntrenadorMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TableEntrenador);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 510, 340));

        Regresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/regresar.png"))); // NOI18N
        Regresar.setContentAreaFilled(false);
        Regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarActionPerformed(evt);
            }
        });
        jPanel1.add(Regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 420, -1, -1));

        Imagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/director (1).png"))); // NOI18N
        jPanel1.add(Imagen, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 10, 170, 170));

        Contenedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/balon.jpg"))); // NOI18N
        jPanel1.add(Contenedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 0, 210, 540));

        wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cancha.jpg"))); // NOI18N
        jPanel1.add(wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 770, 550));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-4, -4, 780, 550));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * cuando se hace clic en el botón "BotonRegistrar", este código verifica 
     * si se han completado los campos requeridos. Si los campos están vacíos, 
     * muestra un mensaje de advertencia. Si los campos tienen valores, crea 
     * un objeto Entrenador, lo guarda en una lista y muestra los registros en 
     * una tabla.
     */
    private void BotonRegistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegistrarMouseClicked
        
    if (nombre.getSelectedItem() == null || equipo.getSelectedItem() == null) {
           
      JOptionPane.showMessageDialog(null,
              "Tienes que rellenar los campos.");
      
        } else {

            Entrenador entrenador = new Entrenador();
            entrenador.setNombre(this.nombre.getSelectedItem().toString());
            entrenador.setEquipo(this.equipo.getSelectedItem().toString());

     entrenadorController.crearRegistro(this.menuVista.listaEntrenador, entrenador);
     entrenadorController.mostrarRegistro(this.menuVista.listaEntrenador, modelo);

        }


    }//GEN-LAST:event_BotonRegistrarMouseClicked

    /**
     * el código busca un entrenador en la lista de entrenadores que tenga el 
     * mismo nombre que el entrenador seleccionado para editar. Si se encuentra 
     * un entrenador con el mismo nombre, se actualiza en la lista y en el origen
     * de datos correspondiente. Luego, se actualiza el modelo de la tabla para
     * mostrar los registros actualizados.
     *
     */
    private void BotonEditarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEditarMouseClicked

        Entrenador entrenador = new Entrenador();
        entrenador.setNombre(this.nombre.getSelectedItem().toString());
        entrenador.setEquipo(this.equipo.getSelectedItem().toString());

        for (int i = 0; i < this.menuVista.listaEntrenador.size(); i++) {
            if (this.menuVista.listaEntrenador.get(i).getNombre().compareTo(
                    entrenador.getNombre()) == 0) {
                this.menuVista.listaEntrenador.set(i, entrenador);

                entrenadorController.actualizarRegistro(this.menuVista.listaEntrenador, entrenador);
                entrenadorController.mostrarRegistro(this.menuVista.listaEntrenador, modelo);

            }
        }

    }//GEN-LAST:event_BotonEditarMouseClicked
    /**
     * el código obtiene el nombre del entrenador seleccionado en la tabla y 
     * muestra un cuadro de diálogo de confirmación
     *
     */
    private void BotonEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEliminarMouseClicked

        String nombre = TableEntrenador.getValueAt(TableEntrenador.getSelectedRow(), 0).toString();
        int opcion = JOptionPane.showConfirmDialog(null, "¿Estás seguro de eliminar?", "Confirmación", JOptionPane.OK_CANCEL_OPTION);
        
        if (opcion == JOptionPane.OK_OPTION) {
            
            entrenadorController.eliminarRegistro(this.menuVista.listaEntrenador, nombre);
            entrenadorController.mostrarRegistro(this.menuVista.listaEntrenador, modelo);
        }
    }//GEN-LAST:event_BotonEliminarMouseClicked

    /**
     *cuando el usuario hace clic en una celda de la tabla TableEntrenador,
     * el nombre y el equipo del entrenador correspondiente se establecen como 
     * elementos seleccionados en los componentes nombre y equipo, respectivamente.
     * 
     */
    private void TableEntrenadorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableEntrenadorMouseClicked

        this.nombre.setSelectedItem(TableEntrenador.getValueAt(TableEntrenador.getSelectedRow(), 0).toString());
        this.equipo.setSelectedItem(TableEntrenador.getValueAt(TableEntrenador.getSelectedRow(), 1).toString());

    }//GEN-LAST:event_TableEntrenadorMouseClicked

    /** 
     *  cuando se activa el evento de acción asociado al método
     * RegresarActionPerformed, la ventana actual se oculta y se muestra 
     * la ventana menuVista, lo que permite regresar al menú principal 
     * de la aplicación.
     */
    private void RegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarActionPerformed
        
        this.setVisible(false);
        this.menuVista.setVisible(true);

    }//GEN-LAST:event_RegresarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonEditar;
    private javax.swing.JButton BotonEliminar;
    private javax.swing.JButton BotonRegistrar;
    private javax.swing.JLabel Contenedor;
    private javax.swing.JLabel Equipo;
    private javax.swing.JLabel Imagen;
    private javax.swing.JLabel Nombre;
    private javax.swing.JButton Regresar;
    private javax.swing.JTable TableEntrenador;
    private javax.swing.JLabel Titulo;
    private javax.swing.JComboBox<String> equipo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> nombre;
    private javax.swing.JLabel wallpaper;
    // End of variables declaration//GEN-END:variables
}
