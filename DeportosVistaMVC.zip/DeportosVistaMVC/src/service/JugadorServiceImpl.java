/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:Service de jugador
 */
package service;

import entity.Jugador;
import model.IJugadorModel;
import model.JugadorModel;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class JugadorServiceImpl implements IJugadorService {

    IJugadorModel model = new JugadorModel();

    /**
     * El método crea un jugador
     *
     * @param lista
     * @param jugador
     */
    @Override
    public void crearRegistro(List<Jugador> lista, Jugador jugador) {
        model.crearRegistro(lista, jugador);
    }

    /**
     * El método elimina un jugador
     *
     * @param lista
     * @param nombre
     */
    @Override
    public void eliminarRegistro(List<Jugador> lista, String nombre) {
        model.eliminarRegistro(lista, nombre);
    }

    /**
     * El método actualiza un jugador
     *
     * @param lista
     * @param jugador
     */
    @Override
    public void actualizarRegistro(List<Jugador> lista, Jugador jugador) {
        model.actualizarRegistro(lista, jugador);
    }

    /**
     * El método muestra un jugador
     *
     * @param lista
     * @param modelo
     */
    @Override
    public void mostrarRegistro(List<Jugador> lista, DefaultTableModel modelo) {
        model.mostrarRegistro(lista, modelo);
    }

}
