/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:ventana vista Arbitro
 */
package service;

import entity.Arbitro;
import java.util.List;
import javax.swing.table.DefaultTableModel;


public interface IArbitroService {
    
     /**
     * El método crea un árbitro
     * @param lista
     * @param arbitro 
     */
    public void crearRegistro(List<Arbitro> lista, Arbitro arbitro);

    /**
     * El método elimina un árbitro 
     * @param lista
     * @param nombre 
     */
    public void eliminarRegistro(List<Arbitro> lista, String nombre);

      /**
     * El método actualiza un árbitro
     * @param lista
     * @param arbitro 
     */
    public void actualizarRegistro(List<Arbitro> lista, Arbitro arbitro);

     /**
     * El método muestra un árbitro
     * @param lista
     * @param modelo 
     */
    public void mostrarRegistro(List<Arbitro> lista, DefaultTableModel modelo);

    
}
