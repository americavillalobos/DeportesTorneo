/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:.ventana vista
 */
package service;

import entity.Entrenador;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public interface IEntrenadorService {
    
    /**
     * El método crea un entrenador
     * @param lista
     * @param entrenador 
     */
    public void crearRegistro(List<Entrenador> lista, Entrenador entrenador);

     /**
     * El método elimina un entrenador 
     * @param lista
     * @param nombre 
     */
    public void eliminarRegistro(List<Entrenador> lista, String nombre);

      /**
     * El método actualiza un árbitro
     * @param lista
     * @param entrenador 
     */
    public void actualizarRegistro(List<Entrenador> lista, Entrenador entrenador);

     /**
     * El método muestra un árbitro
     * @param lista
     * @param modelo 
     */
    public void mostrarRegistro(List<Entrenador> lista, DefaultTableModel modelo);

}
