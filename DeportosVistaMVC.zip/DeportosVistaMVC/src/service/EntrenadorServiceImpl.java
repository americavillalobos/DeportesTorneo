/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:20/05/2023
*Fecha de actualización:21/05/2023
*Descripción:Esta es el Service de entrenador
 */
package service;

import entity.Entrenador;
import model.EntrenadorModelImpl;
import model.IEntrenadorModel;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class EntrenadorServiceImpl implements IEntrenadorService {

    EntrenadorModelImpl model = new IEntrenadorModel();

    /**
     * El método crea un entrenador
     * @param lista
     * @param entrenador 
     */
    @Override
    public void crearRegistro(List<Entrenador> lista, Entrenador entrenador) {
        model.crearRegistro(lista, entrenador);
    }

    /**
     * El método elimina un entrenador 
     * @param lista
     * @param nombre 
     */
    @Override
    public void eliminarRegistro(List<Entrenador> lista, String nombre) {
        model.eliminarRegistro(lista, nombre);
    }

    /**
     * El método actualiza un árbitro
     * @param lista
     * @param entrenador 
     */
    @Override
    public void actualizarRegistro(List<Entrenador> lista, Entrenador entrenador) {
        model.actualizarRegistro(lista, entrenador);
    }

    /**
     * El método muestra un árbitro
     * @param lista
     * @param modelo 
     */
    @Override
    public void mostrarRegistro(List<Entrenador> lista, DefaultTableModel modelo) {
        model.mostrarRegistro(lista, modelo);
    }

}
