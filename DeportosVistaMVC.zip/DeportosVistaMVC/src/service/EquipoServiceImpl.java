/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:clase model Equipo
 */
package service;

import entity.Equipo;
import model.EquipoModelImpl;
import model.IEquipoModel;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class EquipoServiceImpl implements IEquipoService {

    IEquipoModel model = new EquipoModelImpl();

    /**
     * El método crea un equipo
     * @param lista
     * @param equipo 
     */
    @Override
    public void crearRegistro(List<Equipo> lista, Equipo equipo) {
        model.crearRegistro(lista, equipo);
    }
    
    /**
     * El método elimina un equipo
     * @param lista
     * @param nombre 
     */
    @Override
    public void eliminarRegistro(List<Equipo> lista, String nombre) {
        model.eliminarRegistro(lista, nombre);
    }

    /**
     * El método actualiza un equipo
     * @param lista
     * @param equipo 
     */
    @Override
    public void actualizarRegistro(List<Equipo> lista, Equipo equipo) {
        model.actualizarRegistro(lista, equipo);
    }

    /**
     * El método muestra un equipo
     * @param lista
     * @param modelo 
     */
    @Override
    public void mostrarRegistro(List<Equipo> lista, DefaultTableModel modelo) {
        model.mostrarRegistro(lista, modelo);
    }

}
